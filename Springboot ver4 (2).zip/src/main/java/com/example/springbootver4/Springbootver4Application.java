package com.example.springbootver4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootver4Application {

    public static void main(String[] args) {
        SpringApplication.run(Springbootver4Application.class, args);
    }

}
